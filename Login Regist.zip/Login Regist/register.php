<?php
include 'connect.php';

if(isset($_POST['signUp'])){

$firstName=$_POST['fname'];
$lastName=$_POST['lname'];
$email=$_POST['email'];
$password=$_POST['password'];
$password=md5($password);

$checkEmail="SELECT *FROM pengguna WHERE email='$email'";
$result=$conn->query($checkEmail);

if($result->num_rows>0){
    echo "<script>alert('Email telah terdaftar sebelumnya!');</script>";
}

else{
    $insertQuery="INSERT INTO pengguna(firstName,lastName,email,password) VALUES('$firstName','$lastName','$email','$password')";

    if($conn->query($insertQuery)==TRUE){
        echo "<script>alert('Akun telah berhasil dibuat');</script>";
        include 'registerPage.html';
    }

    else{
        echo "Error: ".$conn->error;        
    }
}
}
?>
