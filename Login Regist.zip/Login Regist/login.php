<?php
include 'connect.php';



if(isset($_POST['signIn'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $password=md5($password);

    $sql="SELECT * FROM pengguna WHERE email='$email' AND password='$password'";
    $result=$conn->query($sql);
    if($result->num_rows>0){
        $row=$result->fetch_assoc();
        $_SESSION['email']=$row['email'];
        echo "<script>alert('Selamat datang');</script>";
        include 'index.html';
        exit();
    }

    else{
        echo "<script>alert('Akun tidak terdaftar atau Password salah');</script>";
        include 'loginPage.html';
        

    }
}
?>