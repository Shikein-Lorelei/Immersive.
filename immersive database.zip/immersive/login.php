<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In/Sign Up Form</title>
    <link rel="stylesheet" href="signin.css">
</head>
<body>
    <div class="container">
        <div class="signin-signup">
            <div class="sign-in-form">
                <h2>Sign in</h2>
                <div class="social-icons">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-google"></i></a>
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                </div>
                <p>or use your account</p>
                <form method="POST" action="actionLogin.php">
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <a href="#" class="forgot-password">Forgot your password?</a>
                    <button type="submit">Sign In</button>
                </form>
            </div>
            <div class="sign-up-section">
                <h2>Hello, Friend!</h2>
                <p>Enter your personal details and start journey with us</p>
                <button class="sign-up-btn"><a href="signup.html">Sign Up</a></button>
            </div>
        </div>
    </div>
</body>
</html>