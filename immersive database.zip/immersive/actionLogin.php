<?php

$server = "localhost";
$username = "root";
$password = "";
$database = "immersive";

$conn = new mysqli($server, $username, $password, $database); 

if ($conn->connect_error) { 

 die("Koneksi gagal: " . $conn->connect_error); 

} 

$email = $_POST['email']; 
$password = $_POST['password']; 

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'"; 

$result = $conn->query($sql); 

if ($result->num_rows > 0) { 

 $_SESSION['username'] = $username; 

//  header("Location: welcome.php");
echo "hai"; 

} else { 

 echo "Login gagal. <a href='index.php'>Coba lagi</a>"; 

} 

$conn->close(); 